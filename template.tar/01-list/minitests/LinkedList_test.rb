require 'minitest/autorun'
require 'minitest/spec'

require 'LinkedList'

describe "test" do
  it "fails" do
    assert "true" == "false"
  end
end
