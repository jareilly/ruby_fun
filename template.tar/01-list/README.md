README
===============

Some fun with ruby / lists
