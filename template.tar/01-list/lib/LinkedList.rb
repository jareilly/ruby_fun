=begin
Some of the basic operations that can be performed on a linked list are
1.      Traversing a linked list.
2.      Appending a new node (to the end) of the list
3.      Prepending a new node (to the beginning) of the list
4.      Inserting a new node to a specific position on the list
5.      Deleting a node from the list
6.    Updating the data of a linked list node
=end

class LinkedList

  def initialize
  end

  def append(value)
  end

  def prepend(value)
  end

  def insert(value, position)
  end

  def delete(value, position)
  end

end
