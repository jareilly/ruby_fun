# From wikipedia: http://en.wikibooks.org/wiki/Algorithm_Implementation/Sorting/Merge_sort#Ruby

# mergesort is O(n log n)

def merge_sort(array)
  
  return array if array.size <= 1
  left = merge_sort array[0, array.size / 2]
  right = merge_sort array[array.size / 2, array.size]
 
  merge(left, right)
end
 
 
def merge(left, right)
  result = []
 
  while left.size > 0 && right.size > 0
    result << if left[0] <= right[0]
      left.shift
    else
      right.shift
    end
  end
 
  result.concat(left).concat(right)
end
