# Heapsort is O(n log n)

def heap_sort(array)
  return [] if array.empty? || array.nil?

  # Fail
  return []
end
